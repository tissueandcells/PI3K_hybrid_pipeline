from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
figdir=BASE/'figures'; figdir.mkdir(exist_ok=True)
summary=pd.read_csv(BASE/'data/Table_S8_summary.csv')
acids=pd.read_csv(BASE/'data/Table_S9_all_acidic_contacts.csv')
rmsf=pd.read_csv(BASE/'data/RMSF_all_runs.csv')
series=pd.read_csv(BASE/'data/timeseries_all_runs.csv')
mapping=pd.read_csv(BASE/'data/Table_S10_residue_mapping.csv')
jobs=[('CPD_0332',1),('CPD_0332',2),('CPD_0045',1),('CPD_0045',2),('CPD_0045',3)]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'axes.linewidth':.6,'savefig.facecolor':'white'})
def save(fig,name):
    fig.savefig(figdir/(name+'.png'),dpi=400);fig.savefig(figdir/(name+'.pdf'));plt.close(fig)
labels=[f'{c.replace("CPD_", "")} r{r}' for c,r in jobs]
fig=plt.figure(figsize=(7,6.2),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1,1.2])
ax=fig.add_subplot(gs[0,:]);x=np.arange(5)
for offset,col,color,hatch,legend in [(-.18,'ASP931_distance_occupancy_pct','#cccccc','///','Distance only'),(.18,'ASP931_angular_hbond_occupancy_pct','#444444',None,'Distance + angle')]:
    vals=summary[col].to_numpy();ax.bar(x+offset,vals,width=.34,color=color,edgecolor='black',linewidth=.5,hatch=hatch,label=legend)
    for xx,val in zip(x+offset,vals):ax.text(xx,val+1.5,f'{val:.1f}',ha='center',fontsize=7)
ax.set_xticks(x,labels);ax.set(ylim=(0,115),ylabel='ASP931 occupancy (%)',title='A) ASP931 contacts')
ax.legend(loc='upper left',frameon=False,fontsize=7)
nonzero=sorted(acids.loc[acids.distance_occupancy_pct>0,'topology_resid'].unique())
for j,(col,title) in enumerate([('distance_occupancy_pct','B) Acidic contacts: distance'),('angular_hbond_occupancy_pct','C) Acidic contacts: distance + angle')]):
    ax=fig.add_subplot(gs[1,j]);order=[f'{c}_r{r}' for c,r in jobs]
    matrix=acids.pivot(index='topology_resid',columns='label',values=col).reindex(index=nonzero,columns=order)
    im=ax.imshow(matrix.to_numpy(),vmin=0,vmax=100,cmap='Greys',aspect='auto')
    for yy in range(len(nonzero)):
        for xx in range(5):
            val=matrix.iloc[yy,xx];txt='—' if pd.isna(val) else ('<0.1' if 0<val<.1 else f'{val:.1f}')
            ax.text(xx,yy,txt,ha='center',va='center',fontsize=6.5,color='white' if val>55 else 'black')
    names=[]
    for rid in nonzero:
        v=acids[acids.topology_resid==rid].iloc[0];names.append(f'{v.resname}{int(v.native_resid)}')
    ax.set_yticks(range(len(nonzero)),names);ax.set_xticks(range(5),labels,rotation=45,ha='right');ax.set_title(title)
save(fig,'Figure_10_contact_reanalysis')

fig,axes=plt.subplots(5,2,figsize=(7,7.8),layout='constrained')
for i,(compound,r) in enumerate(jobs):
    label=f'{compound}_r{r}';t=series[series.label==label];f=rmsf[rmsf.label==label]
    ax=axes[i,0];ax.plot(t.time_ns,t.core_backbone_rmsd_A,color='black',lw=.4);ax.axhline(4,color='#777777',ls='--',lw=.6)
    ax.set(xlim=(50,100),ylim=(0,6.2),ylabel='RMSD (Å)',title=f'{chr(65+2*i)}) {compound} r{r}')
    ax=axes[i,1];ax.plot(f.topology_resid,f.RMSF_A,color='black',lw=.65)
    if compound=='CPD_0332':
        for start,end in [(216,222),(287,307),(390,419),(502,512)]:ax.axvspan(start-.5,end+.5,color='#dddddd',zorder=0)
    ax.set(xlim=(int(f.topology_resid.min()),int(f.topology_resid.max())),ylim=(0,9),ylabel='Cα RMSF (Å)',title=f'{chr(66+2*i)}) {compound} r{r}')
axes[-1,0].set_xlabel('Time (ns)');axes[-1,1].set_xlabel('Residue number (topology)')
save(fig,'Figure_11_backbone_RMSD_RMSF')
print(summary.to_string(index=False))
print('Figures generated; nonzero acidic residues:',nonzero)
