CPD_0045 NEUTRAL-FORM PARAMETERIZATION CHECK — 8 OCTOBER 2026

Scope
This folder documents a parameterization calculation for neutral CPD_0045 using the SMILES recorded in the docking manifest and newly generated 3D coordinates. It is distinct from the +1, 48-atom ligand used in production MD, whose records are provided in md/parameterisation/CPD_0045_H and md/production_setup/CPD_0045. The neutral-form results do not validate the production topology or trajectories.

Verified results
- Formula C18H19N5O3S2; 47 atoms (28 heavy atoms, 19 hydrogens).
- ACPYPE 2023.10.27; AmberTools 22.0; GAFF2; AM1-BCC; net charge 0; singlet.
- SQM reports geometry convergence and normal completion.
- Heat of formation: -1.82797663 kcal/mol.
- Total SCF energy: -114138.51459665 kcal/mol.
- Input requests grms_tol=0.0005 and scfconv=1.d-10. The last progress row is not a measurement of the final gradient.
- Raw BCC MOL2 total: -0.001998 e. AMBER prmtop retains the same residual within serialization precision.
- Final GROMACS ITP total: 0.000000 e. ACPYPE applies +0.001998 e to atom 20 (S1, sy), changing +1.518200 to +1.520198 e.
- Final partial-charge range: -0.911800 e (N2, n8) to +1.520198 e (S1, sy).
- MOL2 and ITP atom order/types and bond connectivity agree; input-to-output bond connectivity is preserved.
- FRCMOD contains 8 bond, 17 angle, 24 proper-dihedral data records, and 12 improper records. Counts describe frcmod additions/substitutions, not the full topology.
- Maximum penalty 232 for ca-ca-cc-ss (source X-c2-ca-X) and ca-cc-ss-cc, ns-cc-ss-cc, nd-cc-ss-cc, cd-cc-ss-cc (source X-c2-ss-X).
- Penalty 223 for ca-ca-cc-cd (source c2-ce-ca-ca).
- Eight improper records use default values; the remaining improper penalties are 44.3 and 6.0. No zero penalty is inferred for an unannotated/default record.
- TLEaP: 0 errors, 0 warnings, 0 notes. ACPYPE exit code: 0.

Interpretation
These energies and parameters describe the neutral CPD_0045 check only. They do not describe CPD_0332 or the protonated CPD_0045 production system. Parameter completeness and successful conversion do not independently validate the high-penalty torsions. The original source archive hash is recorded in audit_summary.json. Package versions and force-field hashes are provided in environment_summary.json. Raw numerical calculation outputs are unchanged.

Contents
audit_summary.json: machine-readable findings and source archive hash.
atom_charge_comparison.tsv: all 47 raw and final charges and the correction.
frcmod_substitutions.tsv: every frcmod data record, its source annotation and score.
high_penalty_dihedrals.tsv: the six entries with penalties 232 or 223.
raw/: original SQM, ACPYPE, LEaP, topology and charge files.
environment_summary.json: observed versions and force-field hashes.
SHA256SUMS.txt: hashes of every included file other than this checksum listing.
