"""Recalculate corrected docking summaries from the archived scores.

Usage: python scripts/reproduce_tables.py
Requires Python >=3.10, numpy, pandas and scipy. No new docking or MD is run.
"""
from pathlib import Path
import json, re
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'recalculated';OUT.mkdir(exist_ok=True)
GROUPS=['alpha','beta','delta','gamma']
inventory=pd.read_csv(ROOT/'docking/receptor_inventory.csv')
MAP=dict(zip(inventory.pdb_id,inventory.corrected_isoform))

def aggregate(frame,identifier):
 frame=frame.copy();frame['correct_isoform']=frame.pdb_id.map(MAP)
 assert frame.correct_isoform.notna().all()
 grouped=frame.groupby([identifier,'correct_isoform']).best_affinity
 med=grouped.median().unstack().reindex(columns=GROUPS)
 counts=grouped.count().unstack().reindex(columns=GROUPS)
 iqr=grouped.quantile(.75).unstack()-grouped.quantile(.25).unstack()
 iqr=iqr.reindex(columns=GROUPS).where(counts>=2)
 return med,iqr,counts

raw=pd.read_csv(ROOT/'docking/campaign_original_long.csv')
med,iqr,counts=aggregate(raw,'compound_id')
reported=med.copy();reported['best_score']=med.min(axis=1)
reported['assigned']=med.idxmin(axis=1) # Fixed alpha, beta, delta, gamma tie order.
reported['ddg']=med.apply(lambda r:np.diff(np.sort(r.dropna().to_numpy())[:2])[0]*-1,axis=1)
reported['provisional']=med.isna().any(axis=1)
reported['tied_best']=med.eq(reported.best_score,axis=0).sum(axis=1)>1
reported.to_csv(OUT/'campaign_reported_638.csv')
iqr.to_csv(OUT/'campaign_iqr.csv');counts.to_csv(OUT/'successful_structure_counts.csv')
assert len(raw)==10846 and raw.best_affinity.notna().sum()==10824
assert reported.assigned.value_counts().to_dict()=={'alpha':479,'gamma':73,'beta':54,'delta':32}
assert reported.ddg.le(-1).sum()==22
assert reported.index[reported.provisional].tolist()==['CPD_0514']
assert reported.index[reported.tied_best].tolist()==['CPD_0192']
controls=pd.read_csv(ROOT/'controls/ensemble_cross_dock_original_long.csv')
pose=(ROOT/'controls/serabelisib__PI3Ka_5DXT.pdbqt').read_text()
score=float(re.search(r'REMARK VINA RESULT:\s+(-?[\d.]+)',pose).group(1))
ix=controls.ligand.eq('serabelisib') & controls.pdb_id.eq('5DXT')
assert ix.sum()==1 and score==-10.002
controls.loc[ix,'best_affinity']=score
c,_,_=aggregate(controls,'ligand');c.to_csv(OUT/'control_matrix.csv')
z=(c-c.mean())/c.std(ddof=1);z.to_csv(OUT/'control_zscores.csv')
expected=pd.Series({'alpelisib':'alpha','serabelisib':'alpha','tgx221':'beta','azd6482':'beta','idelalisib':'delta','duvelisib':'delta'})
correct_raw=int((c.idxmin(axis=1).reindex(expected.index)==expected).sum())
correct_z=int((z.idxmin(axis=1).reindex(expected.index)==expected).sum())
assert (correct_raw,correct_z)==(2,3)
d,_,_=aggregate(pd.read_csv(ROOT/'controls/decoy_docking_original_long.csv'),'ligand')
d.to_csv(OUT/'decoy_matrix.csv')
overlap=pd.read_csv(ROOT/'pharmacophore/tolerance_sensitivity.csv')
overlap['abs_delta_delta_G']=overlap.compound.map(reported.ddg.abs())
correlations=[]
for subset in ['all12','nonalpha9']:
 f=overlap if subset=='all12' else overlap[overlap.compound.map(reported.assigned).ne('alpha')]
 for tol in [1.5,2.0,2.5,3.0]:
  r,p=pearsonr(f[f'overlap_{tol:.1f}A'],f.abs_delta_delta_G)
  rho,ps=spearmanr(f[f'overlap_{tol:.1f}A'],f.abs_delta_delta_G)
  correlations.append(dict(subset=subset,n=len(f),tolerance=tol,pearson_r=r,pearson_p=p,spearman_r=rho,spearman_p=ps))
pd.DataFrame(correlations).to_csv(OUT/'pharmacophore_correlations.csv',index=False)
stats={'n_campaign':638,'successful_structure_scores':10824,'assignments':reported.assigned.value_counts().to_dict(),
 'margin_threshold_count':int(reported.ddg.le(-1).sum()),'controls_raw_correct':correct_raw,'controls_z_correct':correct_z,
 'recovered_serabelisib_5DXT':score,'serabelisib_alpha_median':float(c.loc['serabelisib','alpha']),
 'reference_best_mean':float(c.min(axis=1).mean()),'reference_best_sample_sd':float(c.min(axis=1).std(ddof=1))}
(OUT/'summary.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
