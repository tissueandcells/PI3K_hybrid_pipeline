PI3K Source Data

This archive contains docking scores, corrected summaries, per-frame MD
analysis outputs, and selected setup records. No new docking or MD simulations were performed for these corrections.

Reproduce docking summaries:
  python scripts/reproduce_tables.py
Requirements: Python >=3.10, numpy, pandas, scipy. Results go to recalculated/.
The receptor map is four alpha, one beta, six delta and six gamma structures.
Campaign counts include all 638 compounds: CPD_0514 is provisional because beta
is absent; the alpha/beta tie for CPD_0192 uses fixed column order for counting.
Both are flagged. No missing campaign score is imputed. The beta inter-structure
IQR is unavailable. The 12 original evaluation compounds are retained, without
claiming that they are the current three highest-ranked compounds per isoform.

One reference-panel summary failure was recovered from an existing output:
serabelisib/5DXT = -10.002 kcal/mol. Its corrected alpha median is -9.945 and
expected-target margin is -0.416. Original and corrected CSVs are both retained.
There are 136 reference and 68 decoy scores after this recovery.

redocking/: co-crystal inputs, archived nine-pose outputs and verified RMSDs.
3L08 contains GSK2126458/omipalisib (ZIG). 3ZIM contains CNX-1351 (KKR), which
is excluded from the four-case noncovalent validation panel; its archived run
is retained for provenance. RMSDs use element-constrained Hungarian matching
with Euclidean-distance costs in the fixed receptor frame, without ligand fit.

md/: five recorded runs, CPD_0332 r1/r2 and CPD_0045 r1/r2/r3. Source CSVs cover
50-100 ns: 5001 frames for each CPD_0332 run and 10001 for each CPD_0045 run.
Table S8 contains contact and experimental-backbone summaries, S9 all acidic
contacts, S10 residue mapping; RMSF and time series are supplied separately.
Run labels do not establish independent initialisation. The two systems differ
in construct and production settings. Raw trajectories are not included; these
files permit checking the recorded summaries and rebuilding Figures 10-11,
not independently recalculating contact geometry from trajectory coordinates.
Run md/make_figures.py to regenerate the additional MD figures from CSVs.

production_setup/CPD_0045 records the +1, 48-atom production ligand.
parameterisation/CPD_0045_H provides its sqm input/output, optimised structure,
frcmod parameters and verification records. AM1 geometry optimisation converged;
heat of formation = 153.16070885 kcal/mol, total SCF energy = -114298.44091422
kcal/mol. All 20 nonzero proper-torsion terms match the production topology
after unit conversion. The maximum penalty is 319; eight improper entries use
default values. These assignments retain torsional-parameter uncertainty.
separate_neutral_form_QC retains an earlier neutral-form check for provenance;
the manuscript reports the protonated production species.
The archived setup inputs are not evidence of stage-specific convergence.
Original internal names such as 'core' or 'replica' remain in source files for
traceability; the manuscript defines the actual selections and run limitations.

submission_tables/ contains literal CSV exports of each document table object
in order. Extra inventory/aggregate tables mean object numbers are not always
the manuscript's printed table numbers. Use document captions as authoritative.
SHA256SUMS.json lists checksums for the included files. Raw trajectories and
the complete set of trained model weights are not included.
